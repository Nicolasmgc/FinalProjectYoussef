INSERT INTO monitor (id, brand, resolution, price)
VALUES (1, 'LG', '1920x1080', 120.00);

INSERT INTO monitor (id, brand, resolution, price)
VALUES (2, 'Samsung', '1920x1080', 100.00);

INSERT INTO monitor (id, brand, resolution, price)
VALUES (3, 'Dell', '1920x1080', 179.00);

INSERT INTO monitor (id, brand, resolution, price)
VALUES (4, 'AOC', '1920x1080', 220.00);

INSERT INTO student (id, name, surname, exam_date, group_number, task_variant)
VALUES (1, 'Youssef', 'Chraibi', '2022-06-06', 62486, 7);


