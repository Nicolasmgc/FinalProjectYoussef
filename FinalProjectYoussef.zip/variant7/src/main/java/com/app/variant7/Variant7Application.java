package com.app.variant7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Variant7Application {

	public static void main(String[] args) {
		SpringApplication.run(Variant7Application.class, args);
	}

}
