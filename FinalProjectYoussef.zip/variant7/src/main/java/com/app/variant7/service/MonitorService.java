package com.app.variant7.service;

import com.app.variant7.model.Monitor;
import com.app.variant7.repository.MonitorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MonitorService {
    MonitorRepo monitorRepo;

    @Autowired
    public MonitorService(MonitorRepo monitorRepo) {
        this.monitorRepo = monitorRepo;
    }

    public List<Monitor> getAllMonitors() {
        return monitorRepo.findAll();
    }

    public Monitor getMonitorById(Integer id) {
        Optional<Monitor> monitor = monitorRepo.findById(id);
        if (monitor.isPresent()) {
            return monitor.get();
        } else {
            throw new RuntimeException("Monitor Not Found");
        }
    }

    public Double getPriceOfAllMonitor() {
        return monitorRepo.getTotalPriceOfAllMonitors();
    }


}
