package com.app.variant7.model;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
public class Student implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer groupNumber;
    private String name;
    private String surname;
    private int taskVariant;
    private LocalDate examDate;

    public Student() {
    }

    public Student(Integer id, Integer groupNumber, String name, String surname, int taskVariant, LocalDate examDate) {
        this.id = id;
        this.groupNumber = groupNumber;
        this.name = name;
        this.surname = surname;
        this.taskVariant = taskVariant;
        this.examDate = examDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getGroupNumber() {
        return groupNumber;
    }

    public void setGroupNumber(Integer groupNumber) {
        this.groupNumber = groupNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public int getTaskVariant() {
        return taskVariant;
    }

    public void setTaskVariant(int taskVariant) {
        this.taskVariant = taskVariant;
    }

    public LocalDate getExamDate() {
        return examDate;
    }

    public void setExamDate(LocalDate examDate) {
        this.examDate = examDate;
    }
}
