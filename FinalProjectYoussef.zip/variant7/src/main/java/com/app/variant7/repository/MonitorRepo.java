package com.app.variant7.repository;

import com.app.variant7.model.Monitor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MonitorRepo extends JpaRepository<Monitor, Integer> {
    @Query(
            value = "SELECT SUM(price) FROM monitor;",
            nativeQuery = true)
    Double getTotalPriceOfAllMonitors();
}
