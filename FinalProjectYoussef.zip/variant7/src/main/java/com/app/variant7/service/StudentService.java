package com.app.variant7.service;

import com.app.variant7.model.Student;
import com.app.variant7.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentService {
    StudentRepo studentRepo;

    @Autowired
    public StudentService(StudentRepo studentRepo) {
        this.studentRepo = studentRepo;
    }

    public Student info() {
        Optional<Student> student = studentRepo.findById(1);
        if (student.isPresent()) {
            return student.get();
        } else {
            throw new RuntimeException("Student not found");
        }
    }
}
