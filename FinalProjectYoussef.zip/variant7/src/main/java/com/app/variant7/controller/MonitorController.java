package com.app.variant7.controller;

import com.app.variant7.model.Monitor;
import com.app.variant7.service.MonitorService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MonitorController {

    MonitorService monitorService;

    public MonitorController(MonitorService monitorService) {
        this.monitorService = monitorService;
    }

    @GetMapping("/getAll")
    public List<Monitor> getAllBooks() {
        return monitorService.getAllMonitors();
    }

    @GetMapping("/get")
    public Monitor getAllBooks(@RequestParam(name = "id") Integer id) {
        return monitorService.getMonitorById(id);
    }

    @GetMapping("/totalPrice")
    public Double totalPrice() {
        return monitorService.getPriceOfAllMonitor();
    }
}
