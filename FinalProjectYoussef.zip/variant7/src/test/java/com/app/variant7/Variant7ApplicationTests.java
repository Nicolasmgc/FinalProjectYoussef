package com.app.variant7;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Variant7ApplicationTests {

	@Test
	void contextLoads() {
	}

}
